def is_safe(processes, available, max_required, allocated):
    num_processes = len(processes)
    num_resources = len(available)
    finish = [False] * num_processes
    work = available[:]#available.copy()
    need = [[max_required[i][j] - allocated[i][j] for j in range(num_resources)] for i in range(num_processes)]
    while True:
        found = False
        for i in range(num_processes):
            if not finish[i] and all(need[i][j] <= work[j] for j in range(num_resources)):
                work = [work[j] + allocated[i][j] for j in range(num_resources)]
                finish[i] = True
                found = True
        if not found:
            break
    return all(finish)


# Example usage
processes = [0, 1, 2, 3, 4]  # Process IDs
available = [3, 3, 2]  # Available resources
max_required = [
    [7, 5, 3],
    [3, 2, 2],
    [9, 0, 2],
    [2, 2, 2],
    [4, 3, 3]
]  # Maximum resource requirements
allocated = [
    [0, 1, 0],
    [2, 0, 0],
    [3, 0, 2],
    [2, 1, 1],
    [0, 0, 2]
]  # Resources allocated to processes

if is_safe(processes, available, max_required, allocated):
    print("The system is in a safe state.")
else:
    print("The system is in an unsafe state.")
