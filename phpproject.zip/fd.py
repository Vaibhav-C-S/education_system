def is_safe(processes, available, max_required, allocated):
    num_process=len(processes)
    num_resources=len(available)
    work=available[:]
    Found=[False] * num_process
    need=[[max_required[i][j]-allocated[i][j] for j in range(num_resources)]for i in range(num_process)]
    while True:
        found =False
        for i in range(num_process):
            if not Found[i] and all(need[i][j] <= work[j] for j in range(num_resources)):
                work=[work[j] + allocated[i][j] for j in range(num_resources)]
                found=True
                Found[i]=True
        if not found:
                break
    return all(Found)





processes = [0, 1, 2, 3, 4]  # Process IDs
available = [3, 3, 2]  # Available resources
max_required = [
    [7, 5, 3],
    [3, 2, 2],
    [9, 0, 2],
    [2, 2, 2],
    [4, 3, 3]
]  # Maximum resource requirements
allocated = [
    [0, 1, 0],
    [2, 0, 0],
    [3, 0, 2],
    [2, 1, 1],
    [0, 0, 2]
]  # Resources allocated to processes

if is_safe(processes, available, max_required, allocated):
    print("The system is in a safe state.")
else:
    print("The system is in an unsafe state.")