<?php
$conn=new mysqli("localhost","root","","chart");

if(!$conn){
	echo "Connection Failed";
}
?> 